function action(params){
	return new Promise((resolve,reject)=>{
		var Client = require('ssh2').Client;
		var conn = new Client();
		conn.on('ready',()=>{
			installedpackages = [];
			notinstalledpackages = [];
			params.packages.forEach((p)=>{
				conn.exec('yum install -y '+p,(err,stream)=>{
                                	if (err) {
                                        	notinstalledpackages.push(p);
                                	}else{
                                        	stream
                                        	.on('close',(code,signal)=>{
                                                	conn.end();
                                        	})
                                        	.on('data',(data)=>{
                                                	installedpackages.push(p);
                                        	})
                                        	.stderr.on('data', (data) => {
                                                	console.log("error: "+data);
                                        	});
                                	}
                        	});
			});
			resolve({"installed" : installedpackages, "left" : notinstalledpackages});			
		})
		.connect({
			host: params.hostname,
			port: params.port,
			username: params.username,
			password: params.password
		});
	});
}

exports.main = action;
