function action(params){
	return new Promise((resolve,reject)=>{
		var Client = require('ssh2').Client;
		var conn = new Client();
		conn.on('ready',()=>{
			conn.exec('yum install -y nano',(err,stream)=>{
				if (err) {
					reject(error);
				}else{
					stream
					.on('close',(code,signal)=>{
						conn.end();
					})
					.on('data',(data)=>{
						resolve({'status':'nano is instaled succesfully'});
					})
					.stderr.on('data', (data) => {
						resolve({'status':'not installed successfully'});
					});
				}
			});
		})
		.connect({
			host: params.hostname,
			port: params.port,
			username: params.username,
			password: params.password
		});
	});
}

exports.main = action;
