import requests
import urllib3
import time
import json

def main(params):
    urllib3.disable_warnings()

    data = {'username': 'admin', 'password': 'password'}
    headers = {"Content-Type" : "application/json","Accept" : "application/json"}

    url = "https://192.168.60.12:32151/api/v2/authtoken/"
    output = requests.post(url,headers=headers,json=data,verify=False)
    token = output.json()["token"]

    headers = {"Content-Type" : "application/json","Accept" : "application/json","Authorization":"Token "+ token }

    url = "https://192.168.60.12:32151/api/v2/inventories/"
    output = requests.get(url,headers=headers,verify=False)
    inventory_id = ""
    for inventory in output.json()["results"] :
        if inventory["name"] == "test01":
            inventory_id = inventory["id"]
    
    if inventory_id == "" :
        return {"status":"inventory not available"}

    url = "https://192.168.60.12:32151/api/v2/hosts/"
    hosts_id = []
    for host in params["inventory"]:
        data = {"inventory": inventory_id,"name" : host }
        output = requests.post(url,headers=headers,json=data,verify=False)
        if len(json.dumps(output.json())) != 66:
            print(len(json.dumps(output.json())))
            hosts_id.append(output.json()["id"])

    url = "https://192.168.60.12:32151/api/v2/projects/"
    output = requests.get(url,headers=headers,verify=False)
    project_id = ""
    for project in output.json()["results"] :
        if project["name"] == "project01":
            project_id = project["id"]
    
    if project_id == "" :
        return {"status":"project not available"}

    url = "https://192.168.60.12:32151/api/v2/projects/" + str(project_id) +"/"
    data = {"name" : "project01","organization" : 1,"local_path": params["project_name"]}
    output = requests.put(url,headers=headers,json=data,verify=False)
    if len(json.dumps(output.json())) ==40 :
        return {"status" : "local_path does not exists"}

    url = "https://192.168.60.12:32151/api/v2/credentials/"
    data = {"name" : "credential01","organization": 1,"credential_type": 1,"inputs": {"username": params["inputs"]["username"],"password": params["inputs"]["password"]}}
    output = requests.get(url,headers=headers,verify=False)
    credential_id = ""
    for credential in output.json()["results"] :
        if credential["name"] == "credential01":
            credential_id = credential["id"]
    
    url = "https://192.168.60.12:32151/api/v2/credentials/"+str(credential_id)+"/"
    output = requests.put(url,headers=headers,json=data,verify=False)

    url = "https://192.168.60.12:32151/api/v2/job_templates/"+params["template_name"]+"/"
    data = {"name":params["template_name"],"credential":credential_id,"playbook" : params["playbook_name"], "project" : project_id, "inventory": inventory_id}
    output = requests.put(url,headers=headers,json=data,verify=False)
    template_id = output.json()["id"]

    url = "https://192.168.60.12:32151/api/v2/job_templates/"+str(template_id)+"/launch/"
    output = requests.post(url,headers=headers,verify=False)
    job_id = output.json()["id"]
    return {"status" : "Everything is fine"}
    


# print(main({ "inventory" : ["192.168.60.15","192.168.60.16"], "project_name" : "project1", "template_name" : "ExampleTemplate", "playbook_name" : "tets.yml","inputs": {"username": "root","password": "Welcome@1"} }))
