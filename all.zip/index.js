function action(params){
        return new Promise((resolve,reject)=>{
                var Client = require('ssh2').Client;
		params.vm.forEach((v)=>{
			var conn = new Client();
			conn.on('ready',()=>{
                        	installedpackages = [];
                        	notinstalledpackages = [];
                        	params.packages.forEach((p)=>{
                                	conn.exec('yum install -y '+p,(err,stream)=>{
                                        	if (err) {
                                                	notinstalledpackages.push(p);
                                        	}else{
                                                	stream
                                                	.on('close',(code,signal)=>{
                                                        	conn.end();
                                                	})
                                                	.on('data',(data)=>{
                                                        	installedpackages.push("yum");
                                                	})
                                                	.stderr.on('data', (data) => {
                                                        	console.log("error: "+data);
                                                	});
                                        	}
                                	});
                        	});
                        })
                	.connect({
                        	host: v.hostname,
                        	port: v.port,
                        	username: v.username,
                        	password: v.password
                	});
		})
		resolve({"result":"instlled on all vm"});
        });
}

exports.main = action;
